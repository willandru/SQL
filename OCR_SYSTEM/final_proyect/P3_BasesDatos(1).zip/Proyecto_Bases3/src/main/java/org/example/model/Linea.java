package org.example.model;

public class Linea {
    private String placa;
    private int cantidad;
    private double precio;
    private double total;

    public Linea(String placa, int cantidad, double precio, double total) {
        this.placa = placa;
        this.cantidad = cantidad;
        this.precio = precio;
        this.total = total;
    }
    public Linea(){ }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }
    
   

    
}
