package org.example.View;

public class Launcher {
    public static void main(String[] args) {
        App.main(args);
        System.out.println(".... Saliendo de la GUI ");
    }
}