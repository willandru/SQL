package org.example.model;

public class Constantes {
    public static final String USERNAME = "is101019";
    public static final String PASSWORD = "7254010deb";
    public static final String THINCONN = "jdbc:oracle:thin:@orion.javeriana.edu.co:1521/LAB";
}
