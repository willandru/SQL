/**
 * INTEGRANTES:
 * 
 * 1) WILLIAM ANDRES GOMEZ ROA
 * 2) CRISTINA GARCIA GRUNWALDT
 * 3) DANIEL ALFREDO VIDAL DE LEON
 * 4) JESUS DAVID TRASLAVIÑA FUENTES
 * 5) KEVYN ORLANDO PRADA FIGUEROA
 * 
 * USUARIO PARA VERIFICAR TABLAS: IS101019 (WILLIAM)
 * 
 * Se logró llenar la tabla RENTA y la tabla CANTIDADPORBILLETE haciendo consultas
 * para obtener los respectivos ID de los BILLETES y de la RENTA
 * 
 * */
 






package org.example.View;

/**
 * Hello world!
 *
 */
import java.util.List;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import org.example.Controller.FacadeOCR;
import org.example.model.Carro;

import org.example.View.Controller.ControlEventosOCR;

public class App extends Application {
    //private final static String ICON_NAME = "img/car_vehicle_transport_icon_144665.png";
    private final static String MAIN_FXML_NAME = "PantallaOCR.fxml";
    //private final static String STYLE_SHEET_NAME = "styles.css";
    private final static String WINDOW_NAME = "Renta Carros";

    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource(MAIN_FXML_NAME));
        Scene scene = new Scene(root);
        //scene.getStylesheets().add(getClass().getResource(STYLE_SHEET_NAME).toExternalForm());
        //stage.getIcons().add(new Image(getClass().getResourceAsStream(ICON_NAME)));
        stage.setTitle(WINDOW_NAME);
        stage.setMaximized(false);
        stage.setResizable(false);
        
        
        
        
        
        
        
        
        
        
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        
         System.err.println("Hola Mundo");
         
         FacadeOCR rl = new FacadeOCR();
        
         
         
        launch();
       
    }
}