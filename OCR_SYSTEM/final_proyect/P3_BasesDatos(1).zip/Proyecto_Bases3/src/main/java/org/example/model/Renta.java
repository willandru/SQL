package org.example.model;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class Renta {
    
    private String fechaHora;
   // private ArrayList<Linea> lineas;
    //private ArrayList<Billete> pagoBilletes;

    /*public ArrayList<Billete> getPagoBilletes() {
        return pagoBilletes;
    }

    public void setPagoBilletes(ArrayList<Billete> pagoBilletes) {
        this.pagoBilletes = pagoBilletes;
    }
    
    public ArrayList<Linea> getLineas() {
        return lineas;
    }

    public void setLineas(ArrayList<Linea> lineas) {
        this.lineas = lineas;
    }
    
    */

    public Renta(String fechaHora) {
        this.fechaHora = fechaHora;
    }
    
    
    public String getFechaHora() {
        return fechaHora;
    }

    public void setFechaHora(String fechaHora) {
        this.fechaHora = fechaHora;
    }

    
}
