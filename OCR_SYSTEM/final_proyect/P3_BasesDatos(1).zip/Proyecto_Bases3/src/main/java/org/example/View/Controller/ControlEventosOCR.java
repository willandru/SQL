package org.example.View.Controller;

import java.net.URL;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.ResourceBundle;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import org.example.Controller.FacadeOCR;
import org.example.Integration.RepositorioCarro;
import org.example.Integration.RepositorioRenta;
import org.example.model.Billete;
import org.example.model.Carro;
import org.example.model.DtoResumen;
import org.example.model.Linea;
import org.example.model.Renta;

public class ControlEventosOCR implements Initializable{
    
    
    private double TOTAL =0;
    private List<Linea> LINEAS=new ArrayList<>();
    private List<Billete> BILLETES= new ArrayList<>();
    
    private Boolean newRenta=false;
    
    private Renta rentaActual;
    
    
    
    
    private DtoResumen DTO_RESUMEN= new DtoResumen();

    private FacadeOCR facadeOCR  = new FacadeOCR();
    @FXML
    private Button BotonFecha;
    @FXML
    private Button botonAgregarBillete;

    @FXML
    private Button botonAgregarLinea;

    @FXML
    private Button botonEliminarLinea;

    @FXML
    private Button botonNuevaRenta;

    @FXML
    private Button botonReporte;

    @FXML
    private Button botonTerminar;

    @FXML
    private TextField cantidadBilletes;

    @FXML
    private TextField cantidadCarros;

    @FXML
    private ChoiceBox<String> choiceCarro;//Mirar IngresoController.java 
    
    @FXML
    private ChoiceBox<String> choiceDenominacion;

    @FXML
    private TableView<Linea> tablaLineas;
    
    @FXML
    private TableColumn<Linea, Number> columnaCantidad;

    @FXML
    private TableColumn<Linea, String> columnaPlaca ;

    @FXML
    private TableColumn<Linea, Number> columnaPrecio;

    @FXML
    private TableColumn<Linea, Number> columnaSubTotal;

    @FXML
    private Label labelBilletesIngresados;

    @FXML
    private Label labelHoraRenta;
    
    @FXML
    private Label totalRenta;

    @FXML
    private Label labelVueltos;

    @FXML
    void agregarBillete(ActionEvent event) {
        
         
        botonAgregarBillete.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent t) {
                    
                
                int BILLETE= Integer.valueOf(choiceDenominacion.getValue());
                int CANTIDAD =Integer.valueOf(cantidadBilletes.getText());
                
                TOTAL += BILLETE*CANTIDAD;
                
                
                labelBilletesIngresados.setText(String.valueOf(TOTAL));
                   System.out.println(TOTAL );
                   
                   if (newRenta){
                       
                       Billete billete = new Billete(CANTIDAD, BILLETE);
                       BILLETES.add(billete);
                       
                       facadeOCR.crearBillete(billete, rentaActual);
                   }

            }
        });
        
        

    }

    @FXML
    void agregarLinea(ActionEvent event) {
        
        botonAgregarLinea.setOnAction(new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
            
           String CANTIDAD =  cantidadCarros.getText() ; 
           
           String PLACA_PUESTOS =   choiceCarro.getValue();
           String[] words = PLACA_PUESTOS.split(",");
           String[] placas = words[0].split(":");
           String PLACA= placas[1];
           
           Carro carro = facadeOCR.consultarCarro(PLACA);
           
           String placa_carro= carro.getPlaca();
           int cantidad=1;
           double precio_carro= carro.getPrecio();
           double subtotal=precio_carro;
           
          
           
           Linea lineaa= new Linea(placa_carro,cantidad, precio_carro, subtotal);
           
       
           
           columnaPlaca.setCellValueFactory( new PropertyValueFactory<>("placa"));
             columnaPrecio.setCellValueFactory( new PropertyValueFactory<>("precio"));
              columnaCantidad.setCellValueFactory( new PropertyValueFactory<>("cantidad"));
               columnaSubTotal.setCellValueFactory( new PropertyValueFactory<>("total"));
           tablaLineas.setEditable(true);
           tablaLineas.getItems().add(lineaa);
           
           
           LINEAS.add(lineaa);
           
           
           System.out.println(String.valueOf(carro.getPrecio()));
           
            
            
        };
    });
    }

    @FXML
    void eliminarLinea(ActionEvent event) {
        
        botonEliminarLinea.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent t) {
                
                
                int row = tablaLineas.getSelectionModel().getSelectedIndex();
                tablaLineas.getItems().remove(row);
               System.out.println("Hola Mundo");
            };
        });

    }
   

    @FXML
    void generarReporte(ActionEvent event) {

    }

    @FXML
    void nuevaRenta(ActionEvent event) {
        
        String date = facadeOCR.setFecha();
        
         rentaActual= facadeOCR.crearRenta(new Renta(date));
        
        newRenta=true;
        
        labelHoraRenta.setText(date);
        
        // LIMPIAMOS LA INTERFAZ PARA EMPEZAR EN LIMPIIO A AGREGAR DATOS A LA BASE DE DATOS
                tablaLineas.getItems().clear();
               
                choiceCarro.setValue(null);
                cantidadBilletes.setText("");
                labelBilletesIngresados.setText("");
                choiceDenominacion.setValue(null);
        botonNuevaRenta.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent t) {
                
                
               
                
                
                
                
                
                
                
                
                        
                
                
                
                
                
            }
        });
        
        
        
    }

    @FXML
    void terminarRenta(ActionEvent event) {

    }
    
    @Override 
    public void initialize(URL location, ResourceBundle resources) {
    	//panel_2.setVisible(false);
        cargarBilletes();
        cargarCarros();
        cantidadCarros.setText("1");
        cantidadCarros.setDisable(true);
        
        
        
        
        
    	renderVentana();        
    }
    
    @FXML
    void cargarBilletes(){
        List<String> valores = new ArrayList<>();
        valores=facadeOCR.consultarTiposBilletes();
        for (int i = 0; i<valores.size(); i++) {
            System.out.println(i);
            choiceDenominacion.getItems().add(valores.get(i));
        }        
    }
    
    @FXML
    void cargarCarros(){
        List<String> valores = new ArrayList<>();
        valores=facadeOCR.consultarCarros();
        for (int i = 0; i<valores.size(); i++) {
            System.out.println(i);
            choiceCarro.getItems().add(valores.get(i));
        }   
    }
    public void renderVentana()
    {
    	limpiarVentana();
    	//control.escribirDatos();
    	//totalCampus.setText(control.ContarTotal().toString());
    	//listaRegistro.getItems().addAll(control.getRegistro());    	
    	//for(lugar lug: control.getlugaresList())
    	//{
    	//	listaLugares.getItems().add(lug.getNombreCompleto());
    	//}
    }
    
    public void limpiarVentana()
    {
    	//actualizarLugar.setDisable(true);
    	//listaRegistro.getItems().clear();
    	//listaLugares.getItems().clear();
    	//totalCampus.setText("");
    	//IDLugar.setText("");
    	//NombreLugar.setText("");
    	//aforoXLugar.setText("");
    }
 
  private void crearAlerta(AlertType tipo, String titulo, String tituloInterno, String mensaje ){
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setHeaderText(tituloInterno);
        alert.setContentText(mensaje);
        alert.showAndWait();
   }

}
