package org.example.model;

import java.util.ArrayList;

public class DtoResumen {
    private String mensaje;
    private ArrayList<Linea> lineasDtoResumen;
    private int totalRenta;
    private double saldoBillete;
    private double ValorVueltas;

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public ArrayList<Linea> getLineasDtoResumen() {
        return lineasDtoResumen;
    }

    public void setLineasDtoResumen(ArrayList<Linea> lineasDtoResumen) {
        this.lineasDtoResumen = lineasDtoResumen;
    }

    public int getTotalRenta() {
        return totalRenta;
    }

    public void setTotalRenta(int totalRenta) {
        this.totalRenta = totalRenta;
    }

    public double getSaldoBillete() {
        return saldoBillete;
    }

    public void setSaldoBillete(double saldoBillete) {
        this.saldoBillete = saldoBillete;
    }

    public double getValorVueltas() {
        return ValorVueltas;
    }

    public void setValorVueltas(double valorVueltas) {
        ValorVueltas = valorVueltas;
    }
}
