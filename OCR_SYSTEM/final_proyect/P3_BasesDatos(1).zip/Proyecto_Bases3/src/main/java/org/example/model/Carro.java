package org.example.model;

import java.math.BigDecimal;

public class Carro {
    private BigDecimal id;
    private String placa;
    private int unidadesDisponibles;
    private double precio;
    private int puestos;

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public int getUnidadesDisponibles() {
        return unidadesDisponibles;
    }

    public void setUnidadesDisponibles(int unidadesDisponibles) {
        this.unidadesDisponibles = unidadesDisponibles;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getPuestos() {
        return puestos;
    }

    public void setPuestos(int puestos) {
        this.puestos = puestos;
    }

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }
    
    
    
    
    public Carro(BigDecimal carID, String placa, int unidades, double precio) {
        this.id = carID;
        this.placa=placa;
        this.unidadesDisponibles=unidades;
        this.precio=precio;
        
    }
    
     public Carro() {
    }
    
    
    @Override
    public String toString() {
            return  "Placa: " + placa + ", Puestos: " + puestos;
    }

    
    
}
