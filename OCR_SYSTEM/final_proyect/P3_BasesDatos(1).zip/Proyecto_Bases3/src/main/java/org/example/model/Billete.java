package org.example.model;

public class Billete {
    private int cantidad;
    private int denominancion;

     public Billete(){}

    public Billete(int cantidad, int denominancion) {
        this.cantidad = cantidad;
        this.denominancion = denominancion;
    }
     
     
     
    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public int getDenominancion() {
        return denominancion;
    }

    public void setDenominancion(int denominancion) {
        this.denominancion = denominancion;
    }
}
