package org.example.Integration;

import java.math.BigDecimal;
import org.example.model.Constantes;
import org.example.model.DtoResumen;
import org.example.model.Renta;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import org.example.model.Billete;

public class RepositorioRenta {
    public Renta crearRenta(Renta renta) {
        int afectadas = 0;
        String SQL = "insert into RENTA (FECHAHORA )  values (?)";
        try (
                Connection conex = DriverManager.getConnection(
                        Constantes.THINCONN,
                        Constantes.USERNAME,
                        Constantes.PASSWORD);
                PreparedStatement ps = conex.prepareStatement(SQL);) {
            
            
           ps.setString(1, renta.getFechaHora() );
           
            afectadas = ps.executeUpdate();
            return renta;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return renta;
    }
    
   public void crearBillete(Billete billete, Renta rentaActual){
       String SQL = "insert into CantidadPorBillete (Cantidad , BilleteID, RentaID )  values (?,?,?)";
        try (
                Connection conex = DriverManager.getConnection(
                        Constantes.THINCONN,
                        Constantes.USERNAME,
                        Constantes.PASSWORD);
                PreparedStatement ps = conex.prepareStatement(SQL);) {
            
            BigDecimal id_billete= getIdBillete(billete);
            BigDecimal id_renta=getIdRenta(rentaActual);
           ps.setInt(1, billete.getCantidad() );
           ps.setBigDecimal(2, id_billete);
           ps.setBigDecimal(3, id_renta);
           ps.executeUpdate();
            System.out.println("Billete insertado");
           
           
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
     
   }
    public BigDecimal getIdBillete(Billete billete){
        BigDecimal Id=null;
        String denominacion= String.valueOf(billete.getDenominancion());
        String SQL = "select ID from billete where denominacion="+denominacion;
        System.out.println("idBillete   "+ SQL);
        try (
                Connection conex = DriverManager.getConnection(Constantes.THINCONN, Constantes.USERNAME, Constantes.PASSWORD);
                PreparedStatement ps = conex.prepareStatement(SQL);
                ResultSet rs = ps.executeQuery();) {
            while (rs.next()) {
                Id= rs.getBigDecimal("ID");
            }

        } catch (SQLException ex) {
            System.out.println("Error de conexion:" + ex.toString());
            ex.printStackTrace();
        }
        
        System.out.println("idBillete   "+ Id);
        return Id;
    }
    
    
     public BigDecimal getIdRenta(Renta renta){
        BigDecimal Id=null;
        String fecha= renta.getFechaHora();
        String SQL = "select ID from renta where fechaHora="+"'"+fecha+"'";
        System.out.println("idrENTA   "+ SQL);
        try (
                Connection conex = DriverManager.getConnection(Constantes.THINCONN, Constantes.USERNAME, Constantes.PASSWORD);
                PreparedStatement ps = conex.prepareStatement(SQL);
                ResultSet rs = ps.executeQuery();) {
            while (rs.next()) {
                Id= rs.getBigDecimal("ID");
            }

        } catch (SQLException ex) {
            System.out.println("Error de conexion:" + ex.toString());
            ex.printStackTrace();
        }
        System.out.println("idrENTA   "+ Id);
        return Id;
    }
    
// TODO
    public DtoResumen RespRenta(Renta renta){
        String SQL= "select from LINEAS l, RENTA r,CARRO c where  ";
        try(
                Connection conex = DriverManager.getConnection(
                        Constantes.THINCONN,
                        Constantes.USERNAME,
                        Constantes.PASSWORD);
                PreparedStatement ps = conex.prepareStatement(SQL);) {


        }catch (SQLException e){
            e.printStackTrace();
        }
       
       return null;
    }
    
    
     public List<Billete> ConsultarBilletes() {
        List<Billete> billetes = new ArrayList<>();
        String SQL = "select ID, DENOMINACION from billete";
        try (
                Connection conex = DriverManager.getConnection(Constantes.THINCONN, Constantes.USERNAME, Constantes.PASSWORD);
                PreparedStatement ps = conex.prepareStatement(SQL);
                ResultSet rs = ps.executeQuery();) {
            while (rs.next()) {
                billetes.add( buildBillete(rs, billetes));
            }

        } catch (SQLException ex) {
            System.out.println("Error de conexion:" + ex.toString());
            ex.printStackTrace();
            System.out.println("NADA PASO");
        }
        return billetes;
    }
    
    private Billete buildBillete(final ResultSet rs, List<Billete> billetes)throws SQLException{
        Billete billete=new Billete();
        billete.setDenominancion(rs.getInt("DENOMINACION"));
        return billete;
    }
    
    
    
}
