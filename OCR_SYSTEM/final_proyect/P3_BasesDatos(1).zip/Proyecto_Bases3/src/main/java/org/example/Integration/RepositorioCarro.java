package org.example.Integration;

import org.example.model.Carro;
import org.example.model.Constantes;
import org.example.model.Renta;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RepositorioCarro {
    public boolean existenciaCarros(Carro carro){
        String SQL = "select * from CARRO";
        try (
                Connection conex = DriverManager.getConnection(
                        Constantes.THINCONN,
                        Constantes.USERNAME,
                        Constantes.PASSWORD);
                PreparedStatement ps = conex.prepareStatement(SQL);) {
        } catch (SQLException ex) {
            System.out.println("Error de conexion:" + ex.toString());
            ex.printStackTrace();
        }
           return false;
    }
    
    public Carro ConsultarCarro(String placa){
        Carro carro= new Carro();
        placa=placa.replaceAll(" ", "");
      
        String SQL = "SELECT * FROM carro WHERE PLACA="+"'"+placa+"'";
        try (
                Connection conex = DriverManager.getConnection(Constantes.THINCONN, Constantes.USERNAME, Constantes.PASSWORD);
                PreparedStatement ps = conex.prepareStatement(SQL);
                ResultSet rs = ps.executeQuery();) {
            while (rs.next()) {
                buildONECarro(rs, carro);
            }
             } catch (SQLException ex) {
            System.out.println("Error de conexion:" + ex.toString());
            ex.printStackTrace();
        }
       
        return carro;
    }
    
    
     public List<Carro> ConsultarCarros() {
        List<Carro> carros = new ArrayList<>();
        String SQL = "select id, placa, precio, UNIDADESDISPONIBLES, puestos from carro";
        try (
                Connection conex = DriverManager.getConnection(Constantes.THINCONN, Constantes.USERNAME, Constantes.PASSWORD);
                PreparedStatement ps = conex.prepareStatement(SQL);
                ResultSet rs = ps.executeQuery();) {
            while (rs.next()) {
                buildCarro(rs, carros);
            }

        } catch (SQLException ex) {
            System.out.println("Error de conexion:" + ex.toString());
            ex.printStackTrace();
        }
        return carros;
    }
     
      private void buildCarro(final ResultSet rs, List<Carro> carros)
            throws SQLException {
        Carro carro = new Carro();
        carro.setId(rs.getBigDecimal("ID"));
        carro.setPlaca(rs.getString("PLACA"));
        carro.setPrecio(rs.getDouble("PRECIO"));
        carro.setUnidadesDisponibles(rs.getInt("UNIDADESDISPONIBLES"));
        carro.setPuestos(rs.getInt("PUESTOS"));
        carros.add(carro);
    }
      private void buildONECarro(final ResultSet rs, Carro carro)
            throws SQLException {
        
        carro.setId(rs.getBigDecimal("ID"));
        carro.setPlaca(rs.getString("PLACA"));
        carro.setPrecio(rs.getDouble("PRECIO"));
        carro.setUnidadesDisponibles(rs.getInt("UNIDADESDISPONIBLES"));
        carro.setPuestos(rs.getInt("PUESTOS"));
  
    }
    

}
