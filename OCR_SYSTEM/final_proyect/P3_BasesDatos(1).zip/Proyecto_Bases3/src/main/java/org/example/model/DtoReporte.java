package org.example.model;

public class DtoReporte {
}
