package org.example.Controller;

import org.example.Integration.RepositorioCarro;
import org.example.Integration.RepositorioRenta;
import org.example.model.*;

import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

public class FacadeOCR {
    private RepositorioCarro carroContro = new RepositorioCarro();
    private RepositorioRenta rentaContro = new RepositorioRenta();
    
    public FacadeOCR(){}
    
    public DtoResumen construirRespuestaRenta(DtoResumen resumen){
        
        
        
        return resumen;
    }

    public Renta crearRenta( Renta renta) {
        rentaContro.crearRenta(renta);
        return renta;
    }
    
  public void crearBillete(Billete billete, Renta renta){
       rentaContro.crearBillete(billete, renta);
               
   }

    public DtoResumen agregarLinea(){
        return null;
    }

    public DtoResumen eliminarLinea(){
        return null;
    }

    public DtoResumen agregarBillete(){
        
        
        return null;
    }

    public DtoResumen terminarRenta(){
        return null;
    }

    public DtoResumen consultarRenta(){
        return null;
    }

    public DtoReporte consultarAcumulados(){
        return null;
    }

    public List<String> consultarCarros(){
            
        List<String> posibles = new ArrayList<>();
        List<Carro> recopilados = new ArrayList<>();
        recopilados = carroContro.ConsultarCarros();
        
       for (Carro car : recopilados) {
            System.out.println("Carro:" + car.toString());
            posibles.add( String.valueOf(car.toString()) );
            
        }
       return posibles;
    }
    
    public Carro consultarCarro(String placa){
        Carro car = new Carro();
        
        car= carroContro.ConsultarCarro(placa);
        return car;
    }
 

    public  List<String> consultarTiposBilletes(){
        
        List<String> posibles = new ArrayList<>();
        List<Billete> recopilados = new ArrayList<>();
        recopilados = rentaContro.ConsultarBilletes();
        
        for (int i = 0; i< recopilados.size(); i++) {
            //System.out.println(String.valueOf(recopilados.get(i).getDenominancion()));
            posibles.add( String.valueOf(recopilados.get(i).getDenominancion()) );
            
        }
        return posibles;
    }

    public RepositorioCarro getCarroContro() {
        return carroContro;
    }

    public RepositorioRenta getRentaContro() {
        return rentaContro;
    }
    
     public String setFecha(){
        
         Timestamp dateFormatYMD = new java.sql.Timestamp(System.currentTimeMillis());
         System.out.println(dateFormatYMD);
         
          Timestamp stamp = new Timestamp(System.currentTimeMillis());
        Date date = new Date(stamp.getTime());
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy h:mm:ss a");
        sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
        String formattedDate = sdf.format(date); 
        
      System.out.println(formattedDate);
   
            
         
         
         
        return formattedDate;
    }
     
     

}