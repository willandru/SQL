package negocio;

public class Constantes {

    public static final String USERNAME = "XXXXX";
    public static final String PASSWORD = "XXXX";
    public static final String THINCONN = "jdbc:oracle:thin:@orion.javeriana.edu.co:1521/LAB";

}
